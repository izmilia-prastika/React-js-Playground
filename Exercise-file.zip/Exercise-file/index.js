/* latihan 1
var name = "Tika";
name = 'Izmi';
alert(name);
*/

/* Latihan 2, perbedaan penggunaan var dan let
if (true) {
    var name = 'Tika';
}

alert(name);


if (true) {
    let nama = 'Tika';
    nama = 'Izmi';
    alert(nama);
}
*/


/* latihan 3 menggunakan template string
//ada 2 cara, cara baru dan cara lama
let fname = 'Ryan';
let lname = 'D';
let age = prompt("Guess Ryan's age..");

//ini cara lama
//let result = fname + ' ' + lname + ' is ' + age + ' years old';
//alert(result);

//ini cara baru 
let result = `${fname} ${lname} is ${age} years old`;
alert(result);
*/

/* latihan 4 menggunakan default parameter
function welcome(user, message) {
    alert(`Hello ${user}, ${message}`);
}

welcome('Tika', 'Good Morning!');
*/


// cara fungsi biasa
//function greeting(pesan) {
//    return alert(`${pesan} everyone!`);
//}

//cara fungsi arrow
//let greeting = pesan => alert(`${pesan} everyone!`);
//greeting('Good evening!');


/* Latihan 5 Kegunaan Fungsi Arrow
// ini cara lama
let createBlog = (title, body) => {
    if (!title) {
        throw new Error('A title is required');
    }

    if (!body) {
        throw new Error('Body cannot be empty');
    }

    return alert(`${title} - ${body}`);
};

createBlog('Blog title', 'Blog body');
*/

/*cara baru untuk mempersingkat cara lama, yaitu menggunakan fungsi arrow
let greeting = () => alert(`Hello everyone!`);
greeting('Good morning!');*/


/* Cara menggunakan Arrow Function dan This
Cara lama menggunakan fungsi biasa
let nepal = {
    // add property
    mountains: ['Everest', 'Fish Tail', 'Annapurna'],

    // add method
    printWithDash: function(){
        console.log('inside printWithDash', this);
        setTimeout(function() {
            //console.log(this.mountains.join(" - "))
            console.log('inside setTimeout', this);
        }, 3000);
    }
}

//alert(nepal.mountains); cara memunculkan alert dengan isi dari mountains
nepal.printWithDash();

*/

/* Cara baru dengan memakai fungsi arrow
let nepal = {
    // add property
    mountains: ['Everest', 'Fish Tail', 'Annapurna'],

    // add method
    printWithDash: function() {
        setTimeout(() => console.log(this.mountains.join(' - ')), 3000);
    }
};

nepal.printWithDash();
*/


// Cara menggunakan Destructring Object
/*Contoh 1
let thingsToDo = {
    morning: 'Exercise',
    afternoon: 'Work',
    evening: 'Code',
    night: ['Sleep', 'Dream']
};

let { morning, afternoon } = thingsToDo;
morning = 'Run';
afternoon = 'Sleep';
console.log(morning, ' - ', afternoon);
*/

/*Contoh 2
let uniStudent = student => {
    console.log(`${student.name} from ${student.university}`);
};

uniStudent({
    name: 'Ryan',
    university: 'University of Sydney'
});
*/

// Contoh 3
/*let uniStudent = student => {
    let { name, university } = student;
    console.log(`${name} from ${university}`);
};

uniStudent({
    name: 'Ryan',
    university: 'University of Sydney'
}); */


/* Cara menggunakan Destructuring Array
let [, , firstMountain] = ['Everest', 'Fish Tail', 'Annapurna']; //hasilnya Everest
let [, firstMountain] = ['Everest', 'Fish Tail', 'Annapurna']; //hasilnya Fish Tail
let [, , firstMountain] = ['Everest', 'Fish Tail', 'Annapurna']; //hasilnya Annapurna
console.log(firstMountain);
*/


 // Cara menggunakan Restructuring
 /*Contoh 1
 var name = 'Everest';
 var height = 8848;

 var adventureClimbing = { name, height };
 console.log(adventureClimbing);*/

 /*Contoh 2
 var name = 'Everest';
 var height = 8848;
 var output = function () {
     console.log(`Mt. ${this.name} is ${this.height} meter tall`);
 };

 var adventureClimbing = { name, height, output };
 adventureClimbing.output(); */


 /* Contoh 3
 var adventureClimbing = {
     name: 'Everest',
     height: 8848,
     output() {
         console.log(`Mt. ${this.name} is ${this.height} meter tall`);
     }
 };
 adventureClimbing.output();
 */


 // Contoh Penggunaan Operator Spread dan Rest
 // Fungsi ... untuk menggabungkan 2 objek jadi 1
 /* Contoh 1
 var mountains = ['Everest', 'Fish Tail', 'Annapurna'];
 var mountainsFromJapan = ['Fuji'];

 var allMountains = [...mountains, ...mountainsFromJapan];
 console.log(allMountains); */


 /* Contoh 2
 var day = {
     breakfast: 'toast with milk',
     lunch: 'rice with chicken curry'
 }

 var night = {
     dinner: 'noodle soup'
 }

 var picnic = {...day, ...night};

 console.log(picnic); */


 /* Contoh 3
 var rivers = ['Sunkoshi', 'Tamakoshi', 'Saptakoshi'];
 var [first, ...rest] = rivers
 console.log(first);
 console.log(rest); */


 // Cara menggunakan Class Constructor Super
 /* Contoh 1
 function Holiday(destination, days) {
    this.destination = destination;
    this.days = days;
 }

 Holiday.prototype.info = function() {
     console.log(this.destination + ' | ' + this.days + ' days')
 };

 var nepal = new Holiday('Nepal', 30);
 console.log(nepal.info()); */


 /* Contoh 2
 class Holiday {
    constructor(destination, days) {
        this.destination = destination
        this.days = days
    }

    info() {
        console.log(`${this.destination} will take ${this.days} days.`);
    }
 }

 const trip = new Holiday("Kathmandu, Nepal", 30);
 console.log(trip.info());
 */


 // Contoh 3
 // super class
 class Holiday {
     constructor(destination, days) {
         this.destination = destination;
         this.days = days;
     }

     info() {
         console.log(`${this.destination} will take ${this.days} days.`);
     }
 }

 // sub class
 class Expedition extends Holiday {
     constructor(destination, days, gear) {
         super(destination, days);
         this.gear = gear;
     }

     info() {
         super.info();
         console.log(`Bring you ${this.gear.join(" and your")}`)
     }
 }

 const tripWithGear = new Expedition("Everest", 30, ["Sunglasses", "Flags", "Camera"]);
 tripWithGear.info();